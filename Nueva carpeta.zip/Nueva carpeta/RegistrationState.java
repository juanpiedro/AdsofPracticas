package practica5;

public enum RegistrationState{
	STARTED, FILLED, VALIDATED, PAYED, FINISHED, REJECTED;
}
