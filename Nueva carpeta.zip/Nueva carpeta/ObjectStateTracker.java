package practica5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.*;

public class ObjectStateTracker<T1, T2 extends Comparable<T2>>{
	private List<T2> validStates;
	private List<T1> objs;
	private Map<T2, Predicate<T1>> stateFunctionMap;
	
	
	public ObjectStateTracker(T2...states) {
		this.validStates = Arrays.asList(states);
		this.objs = new ArrayList<>();
		this.stateFunctionMap = new HashMap<>();
	}
	
	public ObjectStateTracker<T1, T2> withState(T2 state, Predicate<T1> evaluateCondition) throws IllegalStateException{
		
		if(this.validStates.contains(state) == false) throw new IllegalStateException();
	
		this.stateFunctionMap.put(state, evaluateCondition);
		
		return this;
	}
	
	public void elseState() {
	}
	
	
	public void UpdateStates(){
		for(T2 o: this.validStates) {
		}
		
	}

	public void addObjects(T1 ...objs) { this.objs.addAll(List.of(objs)); }
	
}
